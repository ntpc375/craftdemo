package com.mylocal.craftdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CraftdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
